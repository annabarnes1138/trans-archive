# Advanced Injections Homebrew Tutorial

This tutorial aims to document medium-scale production of HRT
meeting the best safety standards we have for homebrewed HRT while
reducing the odds of contamination as much as reasonably
possible.

## Supplies

This tutorial is NOT trying to be frugal. You’re going to spend over a
thousand dollars (about $900 plus API
cost) getting set up and the consumable costs for this
approach are more expensive than other simpler tutorials. You’re still
likely to save money and stress in the long run despite this vs buying
from homebrewers. The peace of mind that being able to do this yourself
provides cannot be understated, given the world we currently live
in.

### Tools (non-consumable):

1. [Lab Spatulas](https://www.amazon.com/gp/product/B07HHWCNB9)
2. [AWS Gemini 20 Milligram Scale](https://www.amazon.com/gp/product/B0012TDNAM)
3. [Magnetic Stir Bars](https://www.amazon.com/gp/product/B08L3KXRCB)
4. [Glass Beakers](https://www.amazon.com/gp/product/B09VP897PG)
    1. We will use the 100mL and 500 mL ones.
5. [Instant Pot Pro Plus](https://www.amazon.com/dp/B08TMTJZ8L/)
    1. Do NOT use a regular instant pot. It must be a 15
        psi pressure cooker.
    2. If you have an Instant Pot Max (discontinued), that works too.
6. [20mm Vial Crimper](https://www.amazon.com/gp/product/B0752XHKWJ)
7. [Still Air Box](https://www.amazon.com/gp/product/B0C1RCR9BD)
    1. You really need this. It is very difficult to
        control dust without this.
    2. Optional to control dust more, see “Air
        Filtration”:
    3. [20” MERV 13 Air Filter](https://www.amazon.com/gp/product/B01CR9K33K)
    4. [20” Box Fan](https://www.amazon.com/gp/product/B0007Q3RMA/)
    5. [Packing Tape](https://www.amazon.com/dp/B000J07BRQ/)
8. [Vacuum Pump](https://www.amazon.com/dp/B07WS97JWQ)
9. [Hose Fitting for Vacuum Pump](https://www.amazon.com/dp/B09ZLD29NX)
10. [Hose for Vacuum Pump](https://www.amazon.com/dp/B08CT3YDDL)
11. [IR Thermometer](https://www.amazon.com/dp/B00DMI632G)
12. [Hybex Media Bottle 100mL](https://www.medical-and-lab-supplies.com/hybex-100ml-glass-media-storage-bottle-b3000-100-series.html)
    1. Do NOT buy the 50mL one, it won’t fit the
        filters!
    2. You can make up to 150 mL before you hit the filter
        limit.
13. [Magnetic Stirring Hot Plate](https://www.ebay.com/itm/185526706676)
    1. Buy the 380 °C version
14. [Instant Pot Mesh Steamer](https://www.amazon.com/gp/product/B07WSRLD95/)
    1. Optional. Nice for keeping vials and bags higher up
        in the instant pot. You can use the canning rack however for vials
        you will need something else to support them.
15. [Large Mixing Bowls](https://www.amazon.com/dp/B00DK261LM)
16. [Squeeze Bottle](https://www.amazon.com/dp/B0BYZ8CWXG)

### Consumables (long shelf life):

1. [Isopropyl Alcohol 99%](https://www.amazon.com/dp/B078YDHXK9)
    1. Do NOT use “technical grade” isopropyl alcohol. It can [leave an oily residue](https://eamaterials.com/news-1/1724-technical-grade-vs-higher-grade-ipa) and
        contaminate your HRT!
2. [Oxygen Absorbers](https://www.amazon.com/dp/B09YM5BVQJ/)
    1. Optional, but may extend the life of your expensive
        API powders.
3. [5mL Glass Vials](https://www.amazon.com/dp/B0CDB8Y2QB)
    1. 5mL or 3mL vials are suggested for Estradiol
        Undecylate, while 5mL or 10mL vials are suggested for Estradiol
        Enanthate.
    2. Don't buy vials which use flip-off lids, as that
        can compromise the seal on the vial.
3. [10mL Glass Vials](https://www.amazon.com/dp/B099WTYKC4)
4. [3mL Glass Vials](https://www.amazon.com/dp/B0CDB71B9B)
4. [U100 Insulin Syringes](https://www.amazon.com/dp/B07P11F21N)
5. [Weigh Boats](https://www.amazon.com/dp/B07M5RMNPF)
6. [Sterilization Pouches](https://www.amazon.com/dp/B07L9JZBJL)
7. [10mL 18g Syringes](https://www.amazon.com/dp/B09XVK7FJH)
8. [20mL Oral Syringes](https://www.amazon.com/dp/B0C9ZFVYJX)
9. [50mL Benzyl Alcohol](https://www.medical-and-lab-supplies.com/benzyl-alcohol-usp-nf-ultra-pure-non-gmo.html)

### Consumables (per batch):

1. [Castor Oil USP](https://www.amazon.com/dp/B0B72FNDZY)
    1. Must have a “Drug Facts” section if you buy from
        another supplier.
    2. Preferred for Estradiol Undecylate, MCT Oil may
        have difficulty keeping 100 mg/mL in solution and has a 33 percent
        shorter half-life.
2. [Extracto Bottle Top Filter, 500ml, PVDF 0.22µm](https://www.medical-and-lab-supplies.com/extracto-bottle-top-filter-500ml-pvdf-0-22-m.html)
    1. You must use a new one for each batch as they are
        sterile and disposable.
    2. For Castor oil ONLY, PVDF is eaten by MCT
        Oil!
3. For MCT oil use a 0.22µm nylon filter, for
    instance:
    1. [Autofil Bottle Top Filter, 1000mL, Nylon, 0.22µm](https://www.medical-and-lab-supplies.com/autofil-solvent-resistant-pp-bottle-top-filter-500ml-nylon-0-22um-single.html)
4. [MCT Oil 60/40 USP](https://www.medical-and-lab-supplies.com/catalog/product/view/id/24082/s/mct-60-40-caprylic-c8-capric-c10-oil/category/2316/)
    1. Preferred for Estradiol Enanthate. Thinner and
        easier to inject.
    2. May cause irritation if injected Subq for some
        people.

### Pre-sterilized Vials:

You can forgo having to sterilize vials by using
pre-sterilized vials instead. This can save time. Note that using
pre-sterilized plastic media bottles is not suggested because they have
a habit of imploding and also are made of polystyrene which is
incompatible with Benzyl Alcohol.

1. [Vial Decapper](https://www.amazon.com/dp/B08LJK7N9J)
    1. Used to remove caps from pre-sterilized
        vials.
2. [Vial Caps](https://www.amazon.com/dp/B09TKKZ1DT)
3. Pre-sterilized Vials
    1. MedLabSupply (slightly more expensive):
        1. [Clear](https://www.medical-and-lab-supplies.com/vials/sealed-sterile-vials/clear-2-ml-5-ml.html)
        2. [Opaque](https://www.medical-and-lab-supplies.com/vials/sealed-sterile-vials/amber-5ml-10ml.html)
    2. Amazon (be weary of QC issues):
        1. [Link 1](https://www.amazon.com/dp/B091MJLN5X/)
        2. [Link 2](https://www.amazon.com/dp/B0BBS1P8SH/) - Recommend/Tested
        3. [Link 3](https://www.amazon.com/dp/B0BRJCRJMS/)
4. [18g Filter Needles](https://www.vitalitymedical.com/bd-blunt-fill-needle.html)
    1. If you are still having large particulate issues somehow, you can
        use these to eliminate particulate when you are drawing the
        injectable out of the media bottle. Note this is a band-aid solution
        and indicates a problem with your filtration setup.

### Non-pre-sterilized vials

Previous guides cleaned vials only with isopropyl alcohol, which some users
found insufficient. These instructions now recommend Alconox. Before buying
Alconox:

1. [Read the safety data sheet for Alconox](https://alconox.com/wp-content/uploads/2020/07/Alconox-SDS-english.pdf).
2. [Read the
   directions](https://technotes.alconox.com/wp-content/uploads/2020/05/Guide-Directions-and-Optimization.pdf).
3. Get eye protection. Always wear gloves.

!!! warning "Alconox contains [phosphates](https://en.wikipedia.org/wiki/Phosphates_in_detergent), which have been phased out in some places from household detergents. It's bad for the environment. Use it sparingly."

#### Alconox supplies

1. [Alconox](https://www.amazon.com/dp/B0BWLJ8WFH)
2. [Scrub brushes](https://www.amazon.com/dp/B07W426WF2)
3. [A 2-liter jar](https://www.amazon.com/dp/B092XN9PM4)
   to keep the Alconox in (optional, in case the carton leeches or tears)
4. [Scale](https://www.amazon.com/dp/B07D7P7MJJ/) big enough to hold a 1L beaker
4. Distilled water (easier to buy this locally). You'll need the second
   squeeze bottle you bought too.
5. Items from the above list
    * Mixing bowl
    * Squeeze bottle
    * 1L beaker
    * Gloves
    * Lab spatula

### APIs:

We suggest buying APIs from [TeaHRT](https://teahrt.com/product-category/raws/) or [Allie](https://allies-site.org/store.html).

## Pre Setup

### Vacuum Filter

The vacuum filter comes with the incorrect size hose
connection for our filters. You’ll need to wrench off the connection
from the filter to the hose and replace it with the one that we
purchased. Make sure to use thread tape (included) on the new connection
and apply the hose clamp to the tube.

The existing hose connection that comes with the vacuum
pump is extremely fragile. You will likely destroy the brass hose
connection unless you use a box ended wrench. If you accidentally
destroy or strip it like I did, you can wrench off the entire filter and
connect the new hose connection directly to the vacuum pump. Of course,
if you do this, do not use the pump to filter anything explosive.

To test the vacuum pump, put your finger against the
hose and turn on the pump. If it can maintain suction for a few seconds,
the pump is working. (Ideally test this before starting the process, as
if the pump is not working finding out when you are about to filter
solution would be very bad.

### Oxygen Starvers

You can use oxygen starvers to possibly prevent
degrading of the API powder. I recommend doing this, however you may
want to avoid the oxygen starver contacting the powder directly to avoid
excessive contamination of the powder. They go bad after a while and
need to be replaced.

### Air Filtration

If you have a dusty or carpeted house and want to
control dust better than you normally can, you can add a fan and a
filter to the still air box. This will keep consistent, clean airflow
through it. It will also prevent dangerous build-up of solvents if you
do the IPA rinse stage in your still air (or now “moving air”)
box.

1. Open both sides of the still air box.
2. Tape one of the box air filters, metal mesh side
    out, to the outlet of the box fan.
3. Tape the resulting box fan setup to one side of the
    still air box.

For parts of the process which are sensitive to air
flow, such as measuring API, it may be a good idea to close the box and
shut off the fan.

## Pre-Sterilization

The goal is to sterilize anything that the injectable
solution comes in contact with after filtration and reasonably clean
anything which the injectable solution comes into contact with before
filtration. You can also do the optional depyrogenation step, but the
IPA rinse likely removes most pyrogens and you can’t depyrogenate the
injectable solution itself, so it is likely of minimal utility. None of
the injections you can purchase from other homebrewers, even the best,
are completely controlled for pyrogens.

### Cleaning with Alconox

We're using Alconox to get out the kind of stuff you won't get easily with
isopropyl alcohol. We are thus not concerned at this step with dust control,
mostly oil. Set up your mixing bowl next to a sink. Set aside a place to dry
cleaned items, like the extra bowl already clean or a drying rack. Fill the
squeeze bottle with distilled water.

1. Don your gloves and eye protection. If it gets on your skin, rinse your skin.
   If it gets in your eye, flush your eye with water.
2. Put the 1L beaker on the lab scale and turn it on. Measure out 10g of powder.
   Fill it up to 1L with hot tap water, making a 1% solution. Mix gently with
   the lab spatula. Pour it into the mixing bowl.
3. Add your vials, stoppers, beaker, media bottle, media bottle cap and stir bar
   to the bowl. The vials will want to invert with a big bubble; let the air out
   and make sure they're submerged.
4. For each item:
    * Get the right size scrub brush and spend a few seconds scrubbing the
      inside and outside (for glass). For vials, cap them with your thumb and
      shake them gently and pour them out a few times. At this point it should
      be visibly clean.
    * Rinse in hot water to make sure no detergent remains. If Alconox hurts on
      your skin, it probably hurts more under it.
    * Use the squeeze bottle of distilled water to give it one more good rinse.
      There are minerals in tap water we don't want drying on our glass.
    * Put it where you're drying stuff. If you're moving straight to the IPA
      rinse it's not super important that it actually gets dry here, just that
      it doesn't get anything on it except dust.
5. Dispose of the Alconox. It's somewhat better conservation to use this to
   clean less important things on the way out, but don't put anything that's not
   a lab tool in your lab tool cleaning bowl. Make sure to rinse anything that
   touched the detergent before doffing your gloves. Remember not to handle
   anything you just cleaned with bare hands.

This is the point where we start to care about dust, so bring the stuff you just
cleaned into your still air box.

### IPA Rinse and Autoclave Sterilization

!!! note "It's a good idea to do the IPA rinse process for the post-filter items (the ones headed for steam sterilization) in the still air box, but you run the risk of a fire hazard from alcohol vapors unless you did the optional “Air Filtration” setup."

1. Get your catch bowl, don your gloves, and rinse them with the squeeze bottle
   of IPA.
2. Use the squeeze bottle to rinse the inside and outside of all the equipment.
   Be liberal with it. Pre-filter equipment **must** be rinsed and **may** be
   autoclaved:
    1. 100mL beaker
    2. Stir Bar
    3. Lab Spatula for measuring API
    4. Weight Boat (cannot be autoclaved, it will melt)
3. Make sure all IPA has fully evaporated from your pre-filter equipment before
   use. It will evaporate if it gets in your mixture, but it's better not to let
   it happen.
4. Post-filter equipment **must** be rinsed and **must** be autoclaved:
    1. Vials and Vial Stoppers (if not pre-sterilized)
    2. Media Bottle and Cap
5. Dump out any remaining alcohol and place the items in sterilization pouches.
    1. Put the media cap in first, then the bottle, with the bottle top facing
       the cap.
    2. Put vials and stoppers in bags together, one to one. About five to a bag
       works okay for the recommended size, but you can get smaller ones.
    3. Don't cap the bottle or stopper the vials before they go in the autoclave.
6. Seal the sterilization pouches by removing the
    adhesive backing and folding it over.
7. Make sure there is no residue in the Instant Pot’s
    stainless steel container.
8. Fill the Instant Pot Pro Plus up with 2 cups of
    water.
9. Place both mesh steaming baskets or the canning
    rack into the Instant Pot Pro Plus.
10. Place the sterilization pouches into the instant
    pot.
11. Run the instant pot on the canning cycle for 30
    minutes, at max pressure, with no venting (natural cooldown), and no
    keep warm.
12. It should reach a temperature of 250 °F. Allow the
    pot to cool naturally. If you vent it, it will rapidly depressurize,
    splashing water all over everything in the pot.
13. Note: If you make a mistake and the instant pot
    starts emitting steam through the seal due to the sterilization
    pouches contacting the seal, upon opening the instant pot if the
    pouches are very wet, assume everything is contaminated and re-start
    the procedure.
14. Do not open the sterilization pouches until you are
    ready to use the items. Ensure all the water dries from the pouches
    before using the items contained within. You can also place the
    items into an oven at 250 °F to dry them, but be careful of hot
    spots. Do not use any oven which has processed food, as oil will vaporize
    and contaminate your medication.

### Dry Heat Depyrogenation (Optional)

You can also heat items in a regular household oven at
485 °F (250 °C) to sterilize and depyrogenate them. Do not use any oven
which has processed food, as oil will vaporize and contaminate your medication.
Cover the openings of the media bottle and the vials with aluminum foil (rinsed with IPA)
and heat the items for several hours. You cannot depyrogenate the
plastic media bottle cap or rubber vial stoppers. You can purchase
silicone stoppers which can also safely be heated to these temperatures
too.

Depyrogenation is likely not a useful activity since we
cannot combat pyrogens in the actual injection solution we are
preparing. It does have the advantage of eliminating all moisture in the
vials and media bottle, something which may be an issue for steam
sterilization.

## Mixing

There are three formulations which I recommend:

- Estradiol Undecylate 5mL 100 mg/mL
    - 500 mg Estradiol Undecylate
    - 0.1 mL Benzyl Alcohol
    - 4.43 mL Castor Oil
- Estradiol Enanthate 10mL 40 mg/mL
    - 400 mg Estradiol Enanthate
    - 0.2 mL Benzyl Alcohol
    - 9.44 mL MCT Oil or Castor Oil
- Estradiol Enanthate 10mL 50 mg/mL
    - 500 mg Estradiol Enanthate
    - 0.2 mL Benzyl Alcohol
    - 9.35 mL MCT Oil or Castor Oil

To produce a batch, multiply the recipe above by the
number of vials you want. You could potentially lose up to 15 mL of
solution based on other people’s experiences, although with my
procedures the loss was closer to 3mL. Plan accordingly.

**Benzyl Alcohol is not optional.** Some homebrewers make and inject without benzyl alcohol
preservative in their vials. While we are doing everything we can to
prevent biological contamination of our vials, both filtering and heat
sterilization may not be completely effective. Additionally, the multi
dose vial is contaminated with small amounts of air each time you inject
air into the vial before drawing a dose. The benzyl alcohol could
potentially be the last line of defense between you and a serious
infection.

**Benzyl Benzoate** is a solvent which can be used to increase solubility of API in your recipes.
We don't use any in our recipes, but it is commonly used to increase solubility for people who use
estradiol valerate or have issues with API crashing out of solution with some MCT oils. It is not
a preservative, you must use Benzyl Alcohol too regardless. It is commonly suspected to cause
irritation, but we suspect that MCT oil is also associated with irritation too and suggest castor oil
to avoid that risk if you have problems. Benzyl Benzoate is usually used at a concentration of 20-44%,
depending on how much API you need to dissolve, what the API is, and how well your carrier oil holds API.

!!! note "Everything mentioned here should be done in the still air box while wearing gloves which have been rinsed with IPA."

1. Place the stir bar into your 100mL beaker and place
    it on the hot plate. Ensure all IPA is driven off before continuing
    if the beaker is still wet from the IPA rinse.
2. Turn on the hot plate and set it for medium
    heat.
3. Calibrate your Gemini 20 Milligram Scale using the
    instruction manual provided and set the calibration weights aside so
    they do not get in the way.
4. Measure out the desired number of mL of Castor or
    MCT oil into the hot plate.
    1. If you are measuring castor oil, use an oral 20mL
        syringe, otherwise use one of the 10mL 18g ones.
    2. Do not add Benzyl Alcohol yet.
5. Place a weight boat onto the Gemini 20
    Scale.
6. Weight out the desired amount of estradiol powder
    using the lab spatula. Be careful not to accidentally spill the
    powder.
7. Enable stirring on the hot plate.
8. Slowly add the powder to the beaker by folding the
    weigh boat and scooping the powder into the beaker with the lab
    spatula. Be careful not to do this too quickly to avoid splashing
    oil or making a mess.
9. Allow the powder to dissolve into the oil.
    1. Periodically check the temperature of the oil with
        the laser thermometer and try to get it to around 190 °F (90
        °C). Note: If you are using a different recipe with benzyl benzoate
        or already added benzyl alcohol, use the lowest temperature possible,
        not exceeding 140 °F (60 °C).
    2. Once it looks like the powder is dissolved,
        continue stirring for 30 minutes to ensure complete dissolution and
        avoid loss of API.
10. Turn off the heat on the hot plate.
11. Using an insulin syringe, measure out the desired
    amount of Benzyl Alcohol and add it to the beaker.
12. Turn off stirring and use a magnet to retrieve the
    stir bar out of the beaker from the side.

## Filtration

Filtering and controlling dust isn’t
optional. While dust is [unlikely to be life threatening](https://www.pda.org/docs/default-source/website-document-library/publications/industry-perspective-on-medical-risk-of-visible-particles-in-injectable-products.pdf) to inject,
injecting dust should be avoided. Injecting dust subcutaneously can
cause granulomas, which while rarely life threatening, can cause
prolonged pain and [permanent tissue damage](https://radiopaedia.org/cases/injection-granuloma). I'm unsure if injecting
dust can cause more post-injection complications or scarring via IM
injection. I am of the opinion that trans people deserve better than to
be injecting themselves with dust.

This process took about 2 hours to filter 35 mL of
castor oil. Other people have reported times as high as 10 hours for
larger batches. Plan accordingly. Thankfully you don’t have to do much
during this process, unlike with syringe filtering which is manual and
destroys the filter if you press too hard.

!!! note "Everything mentioned here should be done in the still air box while wearing gloves which have been rinsed with IPA."

1. Ensure there is no water inside the media bottle or
    cap while it is still in the sterilization pouch.
2. Open the sterilization pouch containing the media
    bottle.
3. Open the pre-sealed plastic bag containing the
    bottle-top filter.
4. Quickly but calmly attach the two together,
    sideways to help prevent dust from getting in.
5. Connect the vacuum hose to the vacuum
    filter.
6. Pour in all of the injection solution from the
    beaker into the filter and place the cap back onto the
    filter.
    1. Note: If you are making a large castor oil batch,
        for instance larger than \~35 mL, you may want to keep the solution
        warm and add it in smaller increments. The oil cooling down will
        significantly slow filtration and may also increase losses.
7. Activate the vacuum pump.
8. The solution will start filtering. If you are
    filtering castor oil, this process can take hours and happens drip
    by drip. When the drips stop happening after a minute, it is safe to
    assume you are done.
9. Remove the bottle top filter from the media bottle
    and cap it with the media bottle cap.

## Re-Heating the Solution (Castor Only)

If you are processing castor oil, it has likely cooled
down during filtration. This step allows you to process it more easily
and significantly reduce waste. This makes it practical to quickly
handle the castor oil solution with 18g 10mL syringes instead of having
to use more clumsy oral syringes that have higher dead space and may
spill your solution all over the place.

1. Ensure the cap on the media bottle containing your
    injection solution is securely attached.
2. Add about 100mL of water to the 500mL beaker. No
    rinsing of the beaker with IPA is required.
3. Bring the water to a boil using the hot
    plate.
4. Reduce the temperature and place the media bottle
    into the hot water bath for 10 minutes.
5. Remove the media bottle from the hot water
    bath.
6. Wipe off the water and condensation around the
    media bottle.

## Making the Vials

### Filling Vials

!!! note "Everything mentioned here should be done in the still air box while wearing gloves which have been rinsed and dried with IPA. This is one of the most crucial steps as this is the main place where dust can contaminate your end product."

#### For Self-sterilized Vials

1. Ensure the vials and stoppers are free of moisture
    and have dried out before continuing.
2. Open the sterilization pouch containing your vials
    and stoppers.
3. Quickly cap each vial with the stoppers to prevent
    dust contamination.
4. Remove the cap from your media bottle and draw up
    10mL of solution into one of the 18g syringes.
5. With one hand, remove the stopper from the vial
    while measuring out the desired volume of solution into the vial
    with the other one. Keeping the stopper mostly over the vial as you
    fill it can prevent dust getting in and cap it immediately once you
    remove the syringe.
6. Repeat the process until all of the vials are full.
    You may need to tip the media bottle containing the solution when
    filling the syringe for the last one or two vials.

#### For Pre-sterilized Vials

1. Remove the plastic top from the pre-sterilized
    vials.
2. Use the vial decapper to gently but firmly grip on
    the top of the vial seal. Go slowly and pull up gently rotating
    around the vial without fully removing the metal seal.
3. Once the seal is uncrimped all around, use a
    pointed object, such as the cap for a needle, to push down on the
    stopper to prevent it being removed along with the seal. Pull up
    gently to remove the metal seal only.
4. You may want to wipe metal dust off the top of the
    vial stopper if there is any after removing the seal ring.
5. Remove the cap from your media bottle and draw up
    10mL of solution into one of the 18g syringes.
6. Pull up the stopper just enough that you can fit
    the needle around it into the vial. Press down on the stopper to
    hold it against the needle and avoid dust getting in.
    1. Be careful not to scrape the side of the vial with
        the needle.
7. Fill up the vial and pull the needle out, making
    sure to push the stopper back down. Set the vial aside and repeat
    for as many vials as you want to fill.

### Capping the Vials

!!! note "If this is your first time using the vial crimper, you may want to practice on an empty vial. I have never broken a vial during crimping however."

1. Place an aluminum vial cap over the vial.
2. Position the vial crimper over the vial
    evenly.
3. Squeeze the vial crimper, first with one hand and
    then two hands.

## Terminal Sterilization

1. Fill the Instant Pot Pro Plus up with 2 cups of
    water.
2. Place both mesh steaming baskets or the canning
    rack and something to support the vials into the Instant Pot Pro Plus. Do
    not let the vials touch the bottom of the instant pot.
3. Place all of the vials into the top basket of the
    Instant Pot Pro Plus.
4. Run the instant pot on the canning cycle for 1
    hour, at max pressure, with no venting (natural cooldown), and no
    keep warm.
5. It should reach a temperature of 250 °F. Allow the
    pot to cool naturally. If you vent it, it will put more temperature
    stress on the vials.

## Inspection and Labeling

Give your vials some time to allow air bubbles to
dissipate and look for evidence of dust contamination. If the vials are
contaminated, you should consider doing the optional “Air Filtration”
setup outlined earlier in this guide and re-filtering. You should also
label your vials with their ingredients, a batch number, and an
expiration date after determining the vials pass a visual
inspection.

You should record the batch numbers of any oils and
excipients used along with the batch number in a compounding log. Castor
oil solutions can last 2-5 years and MCT Oil solutions can last 3-8
years from the date of manufacture for the oil. The higher numbers are
theoretical, require ideal storage, and exceed recommended use times for
the oil by the manufacturer. Vials should be stored in a dark place free
of excessive heat, as light and excessive heat exposure speed up
degradation. If you freeze your vials in an attempt to extend shelf
life, you may need to place them into boiling water to re-dissolve any
API which precipitates out.

If you are considering selling your vials, please be aware this practice
could be highly illegal in your area and would put you at serious risk.
Should you decide to do so anyways, testing the contents of your vials
through a service such as [Janoshik](https://janoshik.com/) is highly recommended.
It is out of the scope of this guide to advise people how to conduct an
illegal business. Stay safe out there.
