# Homebrewing Info

!!! danger "Homebrewing injections is a potentially hazardous activity. We are sharing this information because there is a lack of public homebrewing information after recent takedowns and evidence online of misinformation that could lead to people seriously harming themselves, most notably through lack of preservative use or filtering."

## Injection Compounding Recommendations

There are many injection tutorials which employ inadequate protection against various hazards which may occur. Here are some to keep in mind to help reduce your risk of complications, pain, and infections.

### Always Use a Preservative

Some homebrewers make and inject without benzyl alcohol preservative in their vials. The multi dose vial is contaminated with small amounts of air each time you inject air into the vial before drawing a dose. Filtering also [doesn't remove all bacteria](https://www.sciencedirect.com/science/article/pii/S0923250804001287), especially if dust gets in afterwards. The benzyl alcohol could potentially be the last line of defense between you and a serious infection.

There are other preservatives apart from benzyl alcohol, but no homebrewers currently use them. We consider any non benzyl alcohol preservatives to be experimental unless directly based on a proven depot oil pharmaceutical formulation. Experimenting with the last line of defense against vial contamination should not be taken lightly.

### Always Control Particulates

You should filter your vials and take measures to avoid dust getting into your product such as rinsing vials and usage of a still air box or filtered workspace. While dust is [unlikely to be life threatening](https://www.pda.org/docs/default-source/website-document-library/publications/industry-perspective-on-medical-risk-of-visible-particles-in-injectable-products.pdf?sfvrsn=2) to inject, injecting dust should be avoided. Injecting dust subcutaneously can cause granulomas, which while rarely life threatening, can cause prolonged pain and [permanent tissue damage](https://radiopaedia.org/cases/injection-granuloma). I'm unsure if injecting dust can cause more post-injection complications or scarring via IM injection.

If you become aware of more robust research or evidence to support not injecting dust, please let me know. I am of the opinion that trans people deserve better than to be injecting themselves with dust.

### Syringe Filters can Break

You can easily break syringe filters. To reduce the odds of breaking syringe filters, use 30mL syringes or larger as that may make it impossibly difficult for you to exert enough force to break your filter, depending on how strong you are. You can do the bubble point test with a plugged syringe to see how much force you can physically exert. The [bubble point test](https://hrtcafe.net/hrtcat/guide/7-bubble-point) can be used to verify filter integrity, but see the comments I wrote in the Sterilizing HRT document for caveats/issues.

### Always Use Steam Sterilization

I recommend using steam-based terminal sterilization in combination with filtering and a preservative. Steam sterilization confers a degree of safety over filtration and aseptic practices alone, especially as it takes place after sealing the solution into the final vials where additional contamination is unlikely before use. My testing and professional opinons in this community suggest steam sterilization is effective and that claims otherwise are not taking into account the amount of heat transfer which actually occurs.

## Tutorials

1. [Injection Tutorial](injection-tutorial.md)
    - A beginner-focused tutorial which makes use of presterilized vials and is fairly robust against dust contamination.
    - Includes bubble point testing procedure.
    - Includes procedure for automating syringe filtering with a vacuum pump.
    - [Sterilizing HRT](sterilizing-hrt.md) - Covers re-sterilizing existing vials only. (May be useful for communities with anti-homebrew rules.)
    - [Estradiol Calculator](../static/estradiol-calc.xlsx) - Use to calculate estradiol recipes.
    - [Vial Lifetime Estimator](../static/deadspace-calc.xlsx) - Used to help you determine how much to brew at a time.
2. [Advanced Injection Tutorial](adv-injection-tutorial.md)
    - Covers injections filtered via vacuum bottle top filtering instead of syringe filters.
    - Less resistant to dust contamination.
3. Non-Injection Tutorials
    - [Anti-Androgen Capsules](capsule-tutorial.md)
         - A more robust encapsulation guide with more safety advice.
         - Contains information on how to develop capsule recipes and mixing to reduce clumps.
    - [Estradiol Transdermal Spray](transdermal-tutorial.md) - An option for transdermal which doesn't require working with gelling agents.
         - Also includes recently developed transdermal progesterone recipe which is less annoying than suppositories.
    - [Estradiol Sublingual Solution](sublingual-tutorial.md) - An estradiol sublingual solution which is easier to make and safer than pills.
    - [Progesterone Suppositories](suppository-tutorial.md) - Suppositories based on PolyBlendRx suppository base.
    - [Progesterone Oil Capsules](oil-capsule-tutorial.md) - Oil progesterone capsules for rectal or oral use.
         - Useful for people who prefer to take progesterone orally or who cannot purchase PolyBlendRx.
4. [Estradiol Gel Recipes](../static/estrogel-wiki.pdf)
    - Contains various community recipes for estradiol and testosterone gel.
    - Some recipies are experimental.
5. [Estradiol Stickies](https://stickies.neocities.org/stickies)
    - An experimental slow-dissolving estradiol pellet for buccal administration.
    - Can be made from E pills to stretch them/obtain more stable levels.

## Additional Resources

### Static

- [NH Dailymed](https://dailymed.nlm.nih.gov/dailymed/) a rather large database of drug formulations in the US.
- [MTFHRT wiki](https://groups.io/g/MTFHRT/wiki) a wiki created by lena's group detailing guides on making gel and injections. Do know that some of the information on this resources is not safe, never inject a multi-use vial without a preservative.
- [IJPC Estradiol Topical Cream](../static/ijpc-estradiol-topical-cream.pdf)
- [IJPC Estradiol Valerate Injection](../static/ijpc-estradiol-valerate.pdf)

### Community

- [MTFHRT groups.io](https://groups.io/g/MTFHRT) a group created by lena for discussion of MTF DIY HRT. Do know that some of the information on this resources is not safe, never inject a multi-use vial without a preservative.

### Services

- [Janoshik Analytical](https://janoshik.com/) a testing service that is happy to test grey market pharmaceuticals.
- [Kykeon Analytics](https://www.kykeonanalytics.com/) - Newer testing service which does HPLC, NMR, FTIR and accepts crypto including Monero. Allows mailing powder samples in an envelope as untracked international postage.

### Useful Vendors

- [Med Lab Supply](https://www.medical-and-lab-supplies.com/) sells excipients and lab supplies

### Offline Usage

You can download the guides posted here using the archive.

- [Homebrew Guide Archive](../static/homebrew.zip)
- [Estradiol Gel Recipes](../static/estrogel-wiki.pdf)
