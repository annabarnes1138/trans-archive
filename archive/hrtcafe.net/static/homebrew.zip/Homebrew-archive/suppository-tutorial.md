# HRT Suppository Tutorial

Progesterone is a frequently used component of HRT,
despite hit-or-miss results many people swear by it and want access to
it. This guide covers production of suppositories which are relatively
inexpensive to make, although the process is annoying.

## Supplies

### Tools (non-consumable):

- Scale
    - [500g (.01 resolution)](https://www.amazon.com/dp/B07D7P7MJJ/) -
        Should be fine for progesterone as the target API amount is 15-30g
        depending on dosage.
    - [20g (.001 resolution)](https://www.amazon.com/dp/B0012TDNAM/)
    - [5kg (0.01 resolution)](https://www.amazon.com/dp/B083NPTMF3)
- [Glass Beakers](https://www.amazon.com/dp/B09VP897PG/)
- [Glass Stirring Rods](https://www.amazon.com/dp/B077H55DGH/)
    - The spade and button end version can be helpful for
        breaking up powder clumps.
- [Hot Plate](https://www.amazon.com/dp/B08V43S4MJ) - Used to heat
    mixture while stirring
    - [Version with Automatic Stirring](https://www.ebay.com/itm/185526706676) (note: optional and heats slower)
    - [Stir Bars](https://www.amazon.com/gp/product/B08L3KXRCB) for use with
        automatic stirring version
- [10mL Glass Pipettes](https://www.amazon.com/dp/B0B1ZDVWS4)
    - Note: These are reported to clog during use
        sometimes, however I did not have the issue.
- [Silicone Mold Sheet](https://www.amazon.com/dp/B0BM9VT7HQ/) - For molding
    suppositories. This mold is heart-shaped and holds roughly 1.2mL per
    mold with 150 mold cavities.

### Consumables:

- Suppository base - Suppository bases are a
    substance which can melt for mixing powder into it, but must set
    back into a solid substance for use. They either melt or dissolve at
    body temperature.
    - [PolyBlend Rx](https://specializedrx.com/products/polyblend-rxtm-suppository-base?_pos%3D1%26_sid%3D625d13591%26_ss%3Dr) - Rather
        costly, but it allows storage of suppositories at room temperature
        without melting.
    - [Coconut Oil](https://www.amazon.com/dp/B07PDXN2Q2/) - Cheap and can
        be bought locally, but suppositories must be refrigerated otherwise
        they will be unusable.
- [Weight Boats](https://www.amazon.com/dp/B07M5RMNPF/) - Optional, but
    makes weighing powders less annoying.

### APIs:

We suggest buying APIs from [TeaHRT](https://teahrt.com/product-category/raws/) or [Allie](https://allies-site.org/store.html).

## Recipe

The target volume for the recipes is 200mL for 150
suppositories. Note you may get some adhesion loss so actual dose per
suppository will likely be slightly less. The cold suppository base in
150 of the 1.2mL takes about 180mL of space.

!!! note "There is no official density provided for PolyBlendRx, the density provided is from my experimentation. Make sure the combined volume is correct."

### 100mg Suppositories

|Ingredient|Mass (g)|Density (g/mL)|Volume (mL)|
|:--:|:--:|:--:|:--:|
|PolyBlend Rx|162.86|0.87|187.2|
|Progesterone|15|1.171|12.8|
|**Total**|202.19||**200 (target)**|

### 200mg Suppositories

|Ingredient|Mass (g)|Density (g/mL)|Volume (mL)|
|:--:|:--:|:--:|:--:|
|PolyBlend Rx|143.44|0.87|164.9|
|Progesterone|30|1.171|35.1|
|**Total**|173.43||**200 (target)**|

## Procedure

Wear gloves and ensure your workspace is clean. Note
that this process is messy. The mold, beaker, and pipettes should be
clean prior to starting, running boiling water through the pipette is a
good way to unclog it. Cleaning with IPA is recommended, but be sure
everything is dry before starting.

1. Weigh out the required amount of PolyBlendRx
    pellets based on the selected recipe above.
2. Set your hot plate to medium heat and mix the
    PolyBlendRx until melted.
3. Weigh out the desired amount of progesterone onto
    one of the weigh boats.
4. Add the progesterone and mix/heat until it
    dissolves.
    1. This can take a few minutes.
    2. Note the progesterone needs heat to dissolve into
        the mixture. More than the PolyBlendRx needs to melt. If you are
        having issues, increase your heat.
5. Reduce the heat level on the mixture until the
    solution can stay in your pipette without dripping all over the
    place. This may take some trial-and-error.
6. Being careful not to drip the mixture, use the
    pipette to fill the suppository molds.
    1. You do not want to overflow the molds, as it will
        quickly make a mess.
    2. Getting down to eye level with the mold every so
        often is a good way to check if the molds are underfilled.
    3. Note the mix shrinks as it cools, so previously
        full molds may appear to be underfilled over time.
7. Transfer the suppository mold to the refrigerator
    to harden.
    1. You may be able to do this without waiting, but be
        careful. It may be safer to wait until they are partially solidified
        first.
    2. Allow the suppositories to cool in the fridge for
        20 minutes.
8. Transfer the suppositories to the final container
    from the mold.
    1. If you are using PolyBlendRx, you can store them at
        room temperature.
    2. If you are using coconut oil, refrigeration is
        required.

## Administration

Take one suppository before bed daily.

To do so, wet the suppository with warm water to soften
and push it in 2 inches rectally. Note that 2 inches isn’t necessarily
required, if the suppository isn’t coming out and isn’t causing an
obvious “need to go to the bathroom” feeling, you inserted it deep
enough. Note it can be more comfortable to take them specifically before
lying down as PolyBlendRx takes a little while to dissolve.
