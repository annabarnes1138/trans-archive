# HRT Transdermal Spray Tutorial

Transdermal estradiol bypasses liver metabolism and
doesn’t require injections. This tutorial explains how to make an
estradiol spray bottle which is a convenient way to apply transdermal
estradiol and doesn’t require handling gelling agents.

## Supplies

### Tools (non-consumable):

- Scale
    - [500g (.01 resolution)](https://www.amazon.com/dp/B07D7P7MJJ/) -
        Should be fine for sublingual dropper as the target API amount is 4g
        at the default batch size.
    - [20g (.001 resolution)](https://www.amazon.com/dp/B0012TDNAM/) - If
        you want to make smaller batch sizes or are worried about precision,
        use this scale.
    - [Weight Boats](https://www.amazon.com/dp/B07M5RMNPF/) - Optional, but
        makes weighing powders less annoying.
    - [5kg (0.01 resolution)](https://www.amazon.com/dp/B083NPTMF3)
- [Glass Beakers](https://www.amazon.com/dp/B09VP897PG/)
- [Glass Stirring Rods](https://www.amazon.com/dp/B077H55DGH/)
    - The spade and button end version can be helpful for
        breaking up powder clumps.
- [Hot Plate](https://www.amazon.com/dp/B08V43S4MJ) - Used to heat
    mixture while stirring
    - [Version with Automatic Stirring](https://www.ebay.com/itm/185526706676) (note: optional and heats slower)
    - [Stir Bars](https://www.amazon.com/gp/product/B08L3KXRCB) for use with automatic stirring
        version

### Consumables:

- [99% Isopropyl Alcohol](https://www.amazon.com/dp/B08JZJ5QV2) - The
    main solvent for the API.
- [Isopropyl Myristate](https://www.amazon.com/dp/B084YZ1XV1) -
    Penetration enhancer to improve bioavailability.
- [Polysorbate 80](https://specializedrx.com/products/polysorbate-80-nf-tween-80?_pos%3D1%26_sid%3Dff10fe4ee%26_ss%3Dr) - Emulsifier
    to prevent separation of excipients.
    - [From Amazon](https://www.amazon.com/dp/B09Y2SZQZ2) - Note: Amazon version is a cosmetics grade product, whereas SpecializedRx sells NF grade.
- 30mL Spray Vials - Used to store and
    administer spray.
    - [From Premium Vials](https://www.premiumvials.com/1-oz-amber-glass-bottle-w-black-smooth-fine-mist-sprayer/) - Original bottles used. Has high MOQ.
    - [From Amazon](https://www.amazon.com/dp/B0CXJ3CZRM/) - Measured at 0.13 mL per spray. (+/- 0.005 mL)

### APIs:

We suggest buying APIs from [TeaHRT](https://teahrt.com/product-category/raws/) or [Allie](https://allies-site.org/store.html).

## Recipe

200mL of 20 mg/mL solution

|Ingredient|Percentage|Volume (mL)|Density (g/mL)|Mass (g)|
|:--:|:--:|:--:|:--:|:--:|
|Estradiol||||4|
|Isopropyl Alcohol|45%|90|0.786|70.74|
|Isopropyl Myristate|45%|90|0.85|76.5|
|Polysorbate 80|10%|20|1.102|22.04|
|**Total**||||**173.28**|

### Transdermal Progesterone

You can also use this recipe to make transdermal progesterone.

200mL of 60 mg/mL solution

|Ingredient|Percentage|Volume (mL)|Density (g/mL)|Mass (g)|
|:--:|:--:|:--:|:--:|:--:|
|Progesterone||||12|
|Isopropyl Alcohol|45%|90|0.786|70.74|
|Isopropyl Myristate|45%|90|0.85|76.5|
|Polysorbate 80|10%|20|1.102|22.04|
|**Total**||||**181.28**|

## Procedure

Wear gloves and ensure your workspace is clean. Ensure
the beaker and other lab supplies are clean before starting, however
with transdermal solutions sterility isn’t as big of a concern as other
methods.

1. Weigh out all of the ingredients into your beaker
    using the recipe above.
2. Place your beaker onto the hot plate at low heat
    and stir until dissolved.
    1. Isopropyl Alcohol is very volatile. Avoid heating
        it excessively (ideally do not heat at all) and avoid open
        flames.
3. Remove the mixture from heat and allow it to cool
    until you can comfortably touch the beaker with your hands.
4. Fill your bottles with the solution and cap
    them.
    1. A funnel or pipette may help with this
        process.

## Administration

The solution may separate, so it is important to shake
well before use.

Typically people administer 1 full spray every 8-12
hours either on the scrotum or armpit for increased absorption. Each
spray is equal to 0.1mL of solution and 2mg of estradiol. Note that the
armpit area is near breast tissue which some people may want to avoid
and has less absorption. Some people may need to administer two
sprays.

Each 30mL bottle contains 600mg of estradiol. At the
dosage listed above, a bottle should last 50-150 days. The entire batch
should last 333-1000 days.
