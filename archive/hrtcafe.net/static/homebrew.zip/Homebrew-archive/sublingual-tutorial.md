# HRT Sublingual Dropper Tutorial

This is an easy to compound oral estradiol solution,
which allows compounding the equivalent of 300 2mg estradiol tablets
into a small dropper bottle.

## Supplies

### Tools (non-consumable):

- Scale
    - [500g (.01 resolution)](https://www.amazon.com/dp/B07D7P7MJJ/) -
        Should be fine for sublingual dropper as the target API amount is
        3.6g at the default batch size.
    - [20g (.001 resolution)](https://www.amazon.com/dp/B0012TDNAM/) - If
        you want to make smaller batch sizes or are worried about precision,
        use this scale.
        - [Weight Boats](https://www.amazon.com/dp/B07M5RMNPF/) - Optional, but makes weighing
            powders less annoying.
    - [5kg (0.01 resolution)](https://www.amazon.com/dp/B083NPTMF3)
- [Glass Beakers](https://www.amazon.com/dp/B09VP897PG/)
- [Glass Stirring Rods](https://www.amazon.com/dp/B077H55DGH/)
    - The spade and button end version can be helpful for
        breaking up powder clumps.
- [Hot Plate](https://www.amazon.com/dp/B08V43S4MJ) - Used to heat
    mixture while stirring
    - [Version with Automatic Stirring](https://www.ebay.com/itm/185526706676) (note: optional and heats slower)
    - [Stir Bars](https://www.amazon.com/gp/product/B08L3KXRCB) for use with automatic stirring
        version

### Consumables:

- [OraPenn SD Sweetened](https://specializedrx.com/products/orapenn%E2%84%A2-sd-anhydrous-sweetened?_pos=1&_sid=76cf357e7&_ss=r) - The
    excipient base for the sublingual oil. It is expensive and has an
    unpleasant taste, but is designed for superior absorption.
    - It may be possible to use MCT oil in place of this,
        but more analysis is needed.
- [Peppermint Burst OS](https://specializedrx.com/products/peppermint-burst-os-natural-liquid-flavor-concentrate?_pos=1&_sid=bc683c1af&_ss=r) - An oil
    mint flavoring to improve the taste of the solution.
- [Polyethylene Glycol 400](https://specializedrx.com/products/polyethylene-glycol-400-nf-clearpeg%e2%84%a2-400) -
    Solvent to prevent API crashing out of solution.
- [30mL Dropper Vials](https://www.premiumvials.com/1-oz-amber-glass-bottle-w-black-calibrated-glass-dropper/) - Used to
    store and administer drops.

### APIs:

We suggest buying APIs from [TeaHRT](https://teahrt.com/product-category/raws/) or [Allie](https://allies-site.org/store.html).

## Recipe

180mL at 20mg/mL

|Ingredient|Percentage|Volume (mL)|Density (g/mL)|Mass (g)|
|:--:|:--:|:--:|:--:|:--:|
|Estradiol||||3.6|
|OraPenn SD|80%|144|0.98|141.12|
|Peppermint Burst OS|10%|18|0.94|16.92|
|Polyethylene Glycol 400|10%|18|1.128|20.30|
|**Total**||**180**||**181.94**|

## Procedure

Wear gloves and ensure your workspace is clean. Ensure
the beaker and other lab supplies are clean before starting, however
with oral solutions sterility isn’t as big of a concern as other
methods.

1. Weigh out all of the ingredients into your beaker
    using the recipe above.
2. Place your beaker onto the hot plate at high heat
    and stir until dissolved.
3. Remove the mixture from heat and allow it to cool
    until you can comfortably touch the beaker with your hands.
    1. Excessive heat could melt the tops of the
        vials.
4. Fill your bottles with the solution and cap
    them.
    1. A funnel or pipette may help with this
        process.

## Administration

The oral solution may separate, so it is important to
shake well before use. Note it also has an unpleasant taste. This recipe
is less likely to have the API crash out.

Typically people take 4-8 drops of solution every 12
hours. Each drop is equal to 0.5mg of estradiol. Avoid food or drink
until the drops are absorbed.

Each 30mL bottle contains 600mg of estradiol. At the
dosage listed above, a bottle should last 75-150 days. The entire batch
should last 450-900 days.
