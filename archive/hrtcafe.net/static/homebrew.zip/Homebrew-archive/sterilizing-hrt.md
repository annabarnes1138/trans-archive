# Sterilizing HRT

Do your vials have dust or hair in them? Did you core
your vial and are now worried about sterility? Follow a questionable
homebrew tutorial and are now worried about what can happen if you
inject dust?

Worry not, as this guide aims to help you solve this
problem while being somewhat cost conscious and not requiring a clean
room or error-prone washing processes. You do not need to rinse vials or
bottles in alcohol and worry about dust getting in during the rinsing
process. The entire fluid path post filtration is pre-sterilized and
disposable.

!!! note "This procedure is not compatible with high viscosity oils unless you do the “vacuum syringe filtering” or “caulk gun filtering” procedure detailed at the end of the document. Don’t try to re-filter castor oil solution by hand unless it is water-like viscosity or you know it has a lot of benzyl benzoate in it."

## Supplies

1. [Instant Pot Pro Plus](https://www.amazon.com/dp/B08TMTJZ8L/)
    1. Do NOT use a regular instant pot. It must be a 15
        psi pressure cooker.
    2. If you have an Instant Pot Max (discontinued), that works too.
    3. If you can’t afford this, a stovetop pressure cooker which can reach
        15 psi is also a good option. A regular Instant Pot [can potentially work](https://journals.plos.org/plosone/article?id=10.1371%2Fjournal.pone.0208769), but you
        would need to run the sterilization cycle for at least 2.5 hours
        instead of 1 hour.
2. [Instant Pot Mesh Steamer](https://www.amazon.com/dp/B07WSRLD95/)
    1. Optional. Nice for keeping vials higher up in the
        instant pot. You can use the canning rack however for vials you will
        need something else to support them. Don’t let them touch the bottom
        of the instant pot.
3. [20mm Vial Crimper](https://www.amazon.com/gp/product/B0752XHKWJ)
4. [Still Air Box](https://www.amazon.com/gp/product/B0C1RCR9BD)
    1. Recommended, especially if you have pets. Usually I
        would say these are mandatory, but in this case the only opportunity
        for dust to intrude is the brief period when you pull the stopper to
        insert the fill needle.
5. [10mL Syringes](https://www.amazon.com/dp/B07KW4KLG2/)
    1. Recommended for bubble point test.
6. [30mL Syringes](https://www.amazon.com/dp/B08HM8N7J2)
    1. If you want to filter more than 30mL of vials, you
        can buy 60mL syringes instead. 60mL syringes also make it even less
        likely to break the filter due to lower achievable pressure, but
        filtering may be slower as a result.
    2. [60mL Syringes](https://www.amazon.com/dp/B0BCX8HDHC/)
7. [Vial Decapper](https://www.amazon.com/dp/B08LJK7N9J)
    1. Used to remove caps from pre-sterilized vials.
        Don't pierce the stoppers on pre-sterilized vials as it is unsafe to
        autoclave them after doing that.
8. [Vial Caps](https://www.amazon.com/dp/B09TKKZ1DT)
9. [18g Needles](https://www.amazon.com/dp/B0C4FBNCRN)
10. [Pre-sterilized Vials](https://www.amazon.com/dp/B0BBS1P8SH/)
    1. If you want to filter more than 2-3 vials or don’t
        want to buy the still air box, also buy large vials (20-100mL)
        enough to fit all of the solution you intend to filter from the
        above link.
    2. Tip! Smaller vials are less likely to get
        contaminated or cored from multiple reuses. Since you are doing the
        work here, there’s no major reason not to use vials smaller than
        10mL. You may have to draw from a 10mL vial over 78 times!
    3. Tip! Amber vs Clear vials: Clear vials are easier
        to inspect for particulates or discoloration of the vial contents.
        Amber vials protect their contents from light making it less likely
        to degrade, but you won’t be able to check for discoloration prior
        to drawing.
    4. Alternatives:
        1. MedLabSupply: [Clear](https://www.medical-and-lab-supplies.com/vials/sealed-sterile-vials/clear-2-ml-5-ml.html), [Opaque](https://www.medical-and-lab-supplies.com/vials/sealed-sterile-vials/amber-5ml-10ml.html)
        2. Amazon: [Link 1](https://www.amazon.com/dp/B091MJLN5X/), [Link 2](https://www.amazon.com/dp/B0BRJCRJMS/)
11. [Nylon Sterile 0.22 µm Syringe Filters](https://www.amazon.com/dp/B06Y11XQ7H)
    1. Only use Nylon or PTFE syringe filters, other
        filter membranes are less compatible for our purposes and could
        dissolve into your medication. They must be individually packaged
        and sterile. Only use 0.22 µm or 0.2 µm filters, nothing larger or
        smaller.
    2. [PVDF 33mm filter](https://www.amazon.com/dp/B09VX7JGXG/) (Faster for
        castor oil without Benzyl Benzoate ONLY)

## Avoiding Filter Breakage

Syringe filters can break if you apply too much
pressure to them. An easy way to avoid this is to use a syringe which is
large. I personally cannot apply more than 63 psi of force to a 30 mL
syringe, meaning it is physically impossible for me to exceed the
syringe filter’s 100 psi limit.

A way you can test if you can physically exceed the syringe filter’s
rated pressure is to do the bubble point test procedure outlined later
in this document, but do it with an extra syringe or a used one after
filtering. Plug the end with your finger and press as hard as possible,
and then do the conversion to determine how much pressure you can exert.

## Procedure

If you have a still air box, set it up now and do all
of these steps inside of it. Wear gloves and wipe them down with an
alcohol swab.

### Uncapping Sterile Vials

1. Remove the plastic top from the pre-sterilized
    vials.
2. Use the vial decapper to gently but firmly grip on
    the top of the vial seal. Go slowly and pull up gently rotating
    around the vial without fully removing the metal seal.
3. Once the seal is uncrimped all around, use a
    pointed object, such as the cap for a needle, to push down on the
    stopper to prevent it being removed along with the seal. Pull up
    gently to remove the metal seal only.
4. You may want to wipe metal dust off the top of the
    vial stopper if there is any after removing the seal ring.

### Filtering

!!! warning "Filtering HRT takes about a minute per mL filtered! If you want to filter 3 vials, it means you will be pressing on a syringe plunger for about 30 minutes."

1. Grab one of the 30mL or 60mL syringes and fit an
    18g drawing needle onto it.
2. Draw up the solution out of the beaker.
    1. Make sure to inject air into the vials while
        drawing to avoid pulling a vacuum. You want the entire vial to go
        into the syringe, so you may need to alternate between drawing and
        injecting more air.
3. If there is any air left in your syringe, now is
    the time to push it out.
4. Remove the 18g needle. Do not re-use this needle
    in the next part.
5. Obtain another new 18g needle.
6. Unwrap a syringe filter and place the needle on the
    output side (luer slip side) of the syringe filter.
7. Install the syringe filter onto your
    syringe.
8. You have two main options for filtering. If you are
    filtering more than 20mL of solution, want to take breaks, or don’t
    have a still air box, continue with this procedure. Otherwise, you
    can directly fill vials from the syringe filter by skipping to step
    2 in the next section.
9. Unwrap a third 18g needle and stick it into your
    intermediate filtering vial directly, not attached to any syringe.
    This vial is 20-100mL depending on how much solution you want to
    filter.
10. Insert the syringe filter needle into the vial. Now
    just push on the syringe.
    1. This can take a while, about 10 minutes per vial.
        If needed, you can take breaks. I suggest switching between hands
        while filtering.
    2. This may sound awful, and it is, but you only have
        to do it once every few years. If you want to mass produce vials,
        consider using vacuum filtration instead. You can also get some of
        the advantages by doing the “vacuum syringe filtering” tutorial at
        the end of this document.
    3. If you are filtering more than 25 mL of solution,
        you may need to switch out additional syringe filters. This mostly
        depends on if the flow rate decreases and your level of
        patience.
11. Once you finish, set the syringe filter assembly
    aside and remove the extra needle stuck in the filtering
    vial.

### Filling & Capping Vials

1. Take a new syringe and 18g needle and draw up the
    solution from the filtering vial. You don’t need to use a large
    syringe here, you can use one of the smaller ones and refill it each
    time.
2. Pull up the stopper just enough that you can fit
    the needle around it into the vial. Press down on the stopper to
    hold it against the needle and avoid dust getting in.
    1. Be careful not to scrape the side of the vial with
        the needle.
3. Fill up the vial and pull the needle out, making
    sure to push the stopper back down. Set the vial aside and repeat
    for as many vials as you want to fill.
4. Place an aluminum vial cap over the vial.
5. Position the vial crimper over the vial
    evenly.
6. Squeeze the vial crimper, first with one hand and
    then two hands.
7. Repeat the steps to cap the rest of the
    vials.

### Terminal Sterilization

1. Fill the Instant Pot Pro Plus up with 2 cups of
    water.
2. Place both mesh steaming baskets or the canning
    rack and something to support the vials into the Instant Pot Pro Plus. Do
    not let the vials touch the bottom of the instant pot.
3. Place all of the vials into the top basket of the
    Instant Pot Pro Plus.
4. Run the instant pot on the canning cycle for 1
    hour, at max pressure, with no venting (natural cooldown), and no
    keep warm.
5. It should reach a temperature of 250 °F. Allow the
    pot to cool naturally. If you vent it, it will put more temperature
    stress on the vials.

## Bubble Point Testing

[HRT Cat](https://hrtcafe.net/hrtcat/guide/7-bubble-point/), the instructions this
bubble point test procedure is based on, claims that bubble point values
are readily available for MCT oil on the manufacturer website. I haven’t
found these values reported for any of the filters I have used or
researched and my own testing suggests the specific liquid used greatly
influences the test results.  If you want to do this test, you need to
also do it on a fresh filter which has been flushed with MCT oil (or
your carrier oil of choice) and compare. If you are using a solvent,
make sure to include that in the test fluid.

Two tests for the filters I linked with MCT oil resulted in 65 psi and
59 psi. A test with Castor oil resulted in 196 psi. Note that if you
test the filter multiple times, subsequent tests may not be valid as the
filter may cease to be completely wet with the test fluid. I suggest
using 10mL syringes. 5mL syringes are too small to be accurate and 30mL
syringes you likely won’t be able to exert the required pressure unless
you are very strong. The bubble point value reported for 0.22 micron
Nylon filters for water is 40-46 psi. [This document](https://www.sigmaaldrich.com/deepweb/assets/sigmaaldrich/product/documents/279/286/bubblepoint-an4364en-ms.pdf) as well as my own
experiments show the bubble point is highly dependent on the liquid
being tested.

1. Find what the barometric pressure in your area
    is.
    1. If you are in the US, you can use [weather.gov](https://www.weather.gov/) to get it.
2. Convert the pressure value from inHg to PSI.
    1. You can use this [online converter](https://www.convertunits.com/from/inhg/to/psi).
    2. To calculate it manually, multiply by
        0.4911.
    3. If you are outside the US, your weather reporting
        may use different pressure units.
3. Ensure there is an 18g needle on your syringe
    filter.
4. Remove the syringe filter from the syringe you were
    using to filter from.
5. Obtain a new or used 10mL syringe and fill it with
    air up to 10mL.
6. Attach the syringe to the syringe filter.
7. Fill a small glass or bowl with water.
8. Dip the needle into the water and press on the
    syringe slowly.
9. When a steady stream of bubbles is emitted from the
    syringe (not every few seconds, constant bubbles), record the value
    on the syringe.
10. Use Boyle’s Law to calculate the pressure from the
    compressed air.
    1. You can use this [online calculator](https://www.omnicalculator.com/physics/boyles-law).
        1. Initial pressure: The pressure obtained from the
            weather forecast.
        2. Initial volume: 10mL
        3. Final volume: The volume recorded from step
            9.
    2. To calculate manually:
        1. Multiply the initial pressure from the weather
            forecast by 10 mL.
        2. Divide that result by the volume recorded from step
            9.
11. The resulting value from the conversion is known as
    the bubble point.
    1. If this value is *significantly* lower (like around half) than the bubble point from
        either the filter specification or a fresh filter, it means your
        filter has been compromised and the solution you filtered is likely
        not sterile.
    2. If the value is similar to the expected bubble
        point, it means you didn’t break your filter and your solution has
        been correctly filtered.
    3. Note that this procedure is an estimate and is not
        extremely accurate.

## Caulk Gun Filtering

This method is cheaper, easier, and 3x faster than vacuum syringe filtering, however
it requires a degree of periodic monitoring of the caulk gun and if you
are inattentive and make a mistake it is easy to rupture the syringe filter.

The basic idea is to have an air bubble in the syringe which you compress with
the caulk gun. It is EXTREMELY important that you do not directly drive the fluid
through the syringe withe the caulk gun, instead you are compressing an air bubble
which drives the fluid through the syringe. You will periodically compress the
syringe more as filtering progresses.

This approach filters oils at the following rates per
my tests (all tests are with the 25mm nylon filters):

1. MCT Oil
    1. With 10 -> 5 mL compression (116 psi bubble point)
        - 45 mL in 44 mins (1.02 mL/min)
    2. With 20 -> 5 mL compression (73 psi bubble point)
        - 22 mL in 9.9 mins (2.22 mL/min)
2. Castor Oil
    1. With 20 -> 5 mL compression (53 psi bubble point, flushed with 2mL MCT)
        - 10 mL in 65 mins (0.153 mL/min)
        - 15 mL in 104 mins (0.144 mL/min)
        - 20 mL in 142 mins (0.141 mL/min)

### Supplies

1. [60mL Syringes](https://www.amazon.com/dp/B0BCX8HDHC/)
    - You can only use up to 45 mL of this syringe capacity.
    - Don't use 30 mL (or smaller) syringes since they will slip through the caulk gun.
2. [Caulk Gun](https://www.amazon.com/dp/B08T9JTHNK/)
    - You can buy cheaper caulk guns, but I like how well this one works.

You'll also want some way to mount the caulk gun to be held up by itself if you are filtering castor oil, as it takes a while. Don't filter directly into final vials as
interrupting the flow of solution from the caulk gun is annoying and will drip solution
all over your workspace.

### Procedure

1. Fill up your syringe with the desired amount of solution. For a 60mL syringe, use up to 45mL.
2. Select a compression ratio. Make sure the maximum PSI is less than the rating on your filter (which is typically 75-100 psi).
    - 10mL -> 5mL (<= 32 psi, safest but slower)
    - 15mL -> 5mL (<= 48 psi)
    - 20mL -> 5mL (<= 64 psi, pay attention not to overcompress)
3. Draw up the larger amount of air listed in the compression ratio.
4. Attach the syringe filter to the syringe and attach the needle to the filter.
5. Insert the needle into your sterile vial.
6. Insert another needle (can be any smaller size) into the sterile vial to vent.
7. Insert the syringe assembly into the caulk gun so that the syringe body is inside the caulk gun.
    - Do NOT insert the body of the syringe filter into the caulk gun, it should be outside it.
    - You may need to compress the syringe slightly to insert it into the caulk gun. If this is needed, ensure the syringe is upright while fitting it into the caulk gun and leave it upright from then on.
8. Use the caulk gun to compress the syringe air bubble to the second number listed in the compression ratio.
9. If you have a mounting solution, prop the caulk gun up, making sure it doesn't restrict your ability to operate it.
10. Over time as filtration progresses, continue to re-compress the air bubble by operating the caulk gun. Be careful not to allow excessive compression, as that can burst the filter.
11. Once you are done filtering, release the caulk gun pressure and remove the needles from the vial.
12. Testing the bubble point of the syringe filter is highly recommended if you are using higher compression ratios or you feel you may have accidentally overcompressed the filter.

## Vacuum Syringe Filtering

In my adventures to make syringe filtering not an awful
hand-cramping experience and allow filtering of viscous oils, I have
tested a vacuum syringe filtering method. Why do this?

1. Bottle top filters which are compatible with benzyl
    benzoate and/or MCT oil are somewhat costly and hard to find.
2. Many (but not all) bottle top filters have housings
    made of plastics which could possibly leech into your HRT due to
    incompatibility with solvents.
3. No more cramping your hands, you can filter large
    amounts of oil without making yourself miserable.
4. This approach maintains the advantages of syringe
    filters and pre-sterilized vials. You can keep everything post
    filtering factory-sterile and nothing ever needs to be washed which
    means saving time, effort, and makes the procedure significantly
    more dust resistant.

This approach filters oils at the following rates per
my tests:

1. MCT Oil
    1. 44.5 mL in 122 mins (0.37 mL/min)
    2. 8 mL in 9.75 mins (0.82 mL/min)
2. Castor Oil
    1. Nylon 25mm filter
        1. 12 mL in 5.6 hrs (0.036 mL/min)
        2. 4.75 mL in 97 minutes (0.049 mL/min)
    2. PVDF 33mm filter
        1. 20 mL in 4.75 hrs (0.07 mL/min)

### Supplies

1. [Vacuum Pump](https://www.amazon.com/dp/B07WS97JWQ)
    1. Note: This vacuum pump is excellent for bottle top
        filters should you choose to buy them in the future.
2. [Hose Fitting for Vacuum Pump](https://www.amazon.com/dp/B09ZLD29NX)
3. [Hose for Vacuum Pump](https://www.amazon.com/dp/B08CT3YDDL)
4. [Test Tube Stand](https://www.amazon.com/dp/B00HUUWYIO)
5. One of either:
    1. [5mL syringes](https://www.amazon.com/dp/B08LMVB4H6)
    2. [Luer Lock to 5/16” Hose Adapter](https://www.amazon.com/dp/B07DHB1KVH)

### Pre Setup

#### Vacuum Filter

The vacuum filter comes with the incorrect size hose
connection for our filters. You’ll need to wrench off the connection
from the filter to the hose and replace it with the one that we
purchased. Make sure to use thread tape (included) on the new connection
and apply the hose clamp to the tube.

The existing hose connection that comes with the vacuum
pump is extremely fragile. You will likely destroy the brass hose
connection unless you use a box ended wrench. If you accidentally
destroy or strip it like I did, you can wrench off the entire filter and
connect the new hose connection directly to the vacuum pump. Of course,
if you do this, do not use the pump to filter anything explosive.

To test the vacuum pump, put your finger against the
hose and turn on the pump. If it can maintain suction for a few seconds,
the pump is working. (Ideally test this before starting the process, as
if the pump is not working finding out when you are about to filter
solution would be very bad.

#### Hose to Luer Lock Adapter

Skip if you bought the finished adapter. The way this
works is you cut one of the 5mL syringes so that it has about an inch of
the tube left. Use thread tape, just thread the other hose adapter you
bought for the vacuum pump into the syringe body. Note there is a chance
you might crack the syringe when cutting it.

### Procedure

Set up the syringe filter and hose as pictured and turn
on the vacuum pump:

![A photo of a vial with a syringe filter inserted into a vial and another needle connected to the vacuum inserted into the vial.](vsf-setup.png)

Try to keep the vial level on the desk and make sure
the needles are only poked into the filtering vial just slightly. You
don’t want the vacuum needle to reach down into the solution and send
your filtered solution into the vacuum pump.
